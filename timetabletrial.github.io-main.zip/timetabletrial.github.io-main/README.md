# timetabletrial.github.io
https://sdgniser.github.io/timetable       is the real deal. I am just trying to edit it for my convenience
